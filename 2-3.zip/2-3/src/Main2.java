public class Main2 {
    public static void main(String[] args) {
    double temperature = 23.5;
    String weather = "晴れ";

    System.out.println("今日の天気: " + weather);
    System.out.println("気温: " + temperature + "℃");
    }
}
