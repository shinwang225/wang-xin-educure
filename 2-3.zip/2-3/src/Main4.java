public class Main4 {
    public static void main(String[] args) {
        System.out.println("彼は\"Java programming\"が好きです。\n" + //
                        "次の行です。\n" + //
                        "\tタブを使用しています。");
    }
}