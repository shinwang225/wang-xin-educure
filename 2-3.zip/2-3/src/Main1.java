public class Main1 {
    public static void main(String[] args){
        int score = 95;
        String studentNumber = "A038";
        boolean pass = true;
        String studentName = "xin wang";

        System.out.println("学生: " + studentName);
        System.out.println("出席番号: " + studentNumber);
        System.out.println("分数: " + score);
        System.out.println("合格か: " + pass);
    }
}