/** 自己紹介のプログラムです。 */
public class Main8 {
    public static void main(String[] args) {
    String name = "山田太郎";
    String birthPlace = "東京都";
    String favoriteFood = "カレーライス";
    /*　初期化した後
     * 出力してください
     */
    System.out.println("=====　自己紹介　=====");
    System.out.println("名前: " + name);
    System.out.println("出身地: " + birthPlace);
    System.out.println("好きな食べ物: " + favoriteFood);
    }
}
