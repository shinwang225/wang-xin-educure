public class Main7 {
    public static void main(String[] args) {
        // 名前、名字、年齢、メールアドレスの4つの変数を使用してください。
    String lastname = "山田";
    String firstname = "太郎";
    int age = 16;
    String mailaddress = "yamada@example.com";

    System.out.println("名前: " + lastname + " " +firstname);
    System.out.println("年齢: " + age + "歳");
    System.out.println("メールアドレス: " + mailaddress);
    }
}