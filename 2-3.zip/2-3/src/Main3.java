/**このクラスは「Hello, World!」を表示するため
 * のサンプルプログラムです。*/
public class Main3 {
    public static void main(String[] args) {
        /*プログラムの名前はMain３です。
        ここでは"Hello, World!"を入力してください。*/
        System.out.println("Hello, World!");//画面に文字を表示する
    }
}
